import React from 'react';
import { Linkedin, Mail, Star } from 'lucide-react';

const Team = () => {
  const teamMembers = [
    {
      name: "Sarah Johnson",
      role: "Creative Director",
      bio: "10+ years in fashion design with a passion for sustainable luxury",
      avatar: "👩‍🎨",
      rating: 4.9,
      specialties: ["Design", "Sustainability", "Luxury"]
    },
    {
      name: "Michael Chen",
      role: "Operations Manager", 
      bio: "Expert in supply chain optimization and customer experience",
      avatar: "👨‍💼",
      rating: 4.8,
      specialties: ["Operations", "Logistics", "Strategy"]
    },
    {
      name: "Emma Rodriguez",
      role: "Brand Manager",
      bio: "Marketing strategist with expertise in digital brand building",
      avatar: "👩‍💻",
      rating: 4.9,
      specialties: ["Marketing", "Branding", "Digital"]
    },
    {
      name: "David Thompson",
      role: "Head Stylist",
      bio: "Celebrity stylist turned personal shopping consultant",
      avatar: "👨‍🎨",
      rating: 4.7,
      specialties: ["Styling", "Personal Shopping", "Trends"]
    },
    {
      name: "Lisa Park",
      role: "Customer Success",
      bio: "Dedicated to ensuring every customer has an exceptional experience", 
      avatar: "👩‍💼",
      rating: 4.9,
      specialties: ["Customer Care", "Support", "Relations"]
    },
    {
      name: "James Wilson",
      role: "Quality Assurance",
      bio: "15 years ensuring product quality and manufacturing excellence",
      avatar: "👨‍🔬",
      rating: 4.8,
      specialties: ["Quality Control", "Manufacturing", "Standards"]
    }
  ];

  return (
    <section id="team" className="py-20 bg-gradient-to-b from-white to-purple-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Meet Our <span className="bg-gradient-to-r from-rose-500 to-purple-600 bg-clip-text text-transparent">Team</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            The passionate individuals behind Style who work tirelessly to bring you the best in fashion and customer experience.
          </p>
        </div>

        {/* Team Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {teamMembers.map((member, index) => (
            <div key={index} className="group bg-white/70 backdrop-blur-sm rounded-3xl p-8 border border-white/50 shadow-lg hover:shadow-2xl transition-all duration-500 hover:-translate-y-2">
              {/* Avatar */}
              <div className="text-center mb-6">
                <div className="inline-flex items-center justify-center w-24 h-24 bg-gradient-to-br from-rose-400 to-purple-500 rounded-full text-4xl mb-4 group-hover:scale-110 transition-transform duration-300">
                  {member.avatar}
                </div>
                
                {/* Rating */}
                <div className="flex items-center justify-center space-x-1 mb-2">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  ))}
                  <span className="text-sm text-gray-600 ml-2">({member.rating})</span>
                </div>
              </div>

              {/* Content */}
              <div className="text-center">
                <h3 className="text-xl font-bold text-gray-900 mb-2">{member.name}</h3>
                <p className="text-rose-500 font-semibold mb-4">{member.role}</p>
                <p className="text-gray-600 mb-6 leading-relaxed">{member.bio}</p>

                {/* Specialties */}
                <div className="flex flex-wrap gap-2 justify-center mb-6">
                  {member.specialties.map((specialty, i) => (
                    <span key={i} className="px-3 py-1 bg-gradient-to-r from-rose-100 to-purple-100 text-rose-700 text-sm rounded-full">
                      {specialty}
                    </span>
                  ))}
                </div>

                {/* Social Links */}
                <div className="flex justify-center space-x-4">
                  <button className="p-2 rounded-full bg-gradient-to-r from-rose-400 to-purple-500 text-white hover:from-rose-500 hover:to-purple-600 transition-all duration-300 hover:scale-110">
                    <Linkedin className="w-4 h-4" />
                  </button>
                  <button className="p-2 rounded-full bg-gradient-to-r from-rose-400 to-purple-500 text-white hover:from-rose-500 hover:to-purple-600 transition-all duration-300 hover:scale-110">
                    <Mail className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Stats Section */}
        <div className="mt-16 grid md:grid-cols-3 gap-8 text-center">
          <div className="p-8 bg-white/50 backdrop-blur-sm rounded-2xl border border-white/50">
            <div className="text-4xl font-bold text-rose-500 mb-2">50+</div>
            <div className="text-gray-600">Team Members</div>
          </div>
          <div className="p-8 bg-white/50 backdrop-blur-sm rounded-2xl border border-white/50">
            <div className="text-4xl font-bold text-purple-500 mb-2">15+</div>
            <div className="text-gray-600">Years Combined Experience</div>
          </div>
          <div className="p-8 bg-white/50 backdrop-blur-sm rounded-2xl border border-white/50">
            <div className="text-4xl font-bold text-emerald-500 mb-2">4.8</div>
            <div className="text-gray-600">Average Team Rating</div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Team;