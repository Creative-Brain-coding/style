import React from 'react';
import { ArrowRight, Sparkles } from 'lucide-react';

const Hero = () => {
  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden bg-gradient-to-br from-rose-50 via-white to-purple-50">
      {/* Animated Background Elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-20 left-10 w-32 h-32 bg-rose-200 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-pulse"></div>
        <div className="absolute top-40 right-10 w-24 h-24 bg-purple-200 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-bounce"></div>
        <div className="absolute bottom-20 left-20 w-28 h-28 bg-emerald-200 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-ping"></div>
        <div className="absolute bottom-40 right-20 w-20 h-20 bg-rose-300 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-pulse"></div>
      </div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Text Content */}
          <div className="text-center lg:text-left">
            <div className="inline-flex items-center px-4 py-2 bg-gradient-to-r from-rose-100 to-purple-100 rounded-full text-sm text-rose-700 mb-6 animate-fade-in">
              <Sparkles className="w-4 h-4 mr-2" />
              New Collection Available
            </div>
            
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-gray-900 mb-6 leading-tight">
              Discover Your
              <span className="block bg-gradient-to-r from-rose-500 via-purple-500 to-emerald-500 bg-clip-text text-transparent">
                Perfect Style
              </span>
            </h1>
            
            <p className="text-xl text-gray-600 mb-8 max-w-2xl">
              Elevate your wardrobe with our curated collection of premium clothing for women, children, and men. Fashion that speaks your language.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <button className="group bg-gradient-to-r from-rose-500 to-purple-600 text-white px-8 py-4 rounded-full font-semibold hover:from-rose-600 hover:to-purple-700 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:-translate-y-1">
                Shop Now
                <ArrowRight className="inline-block ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </button>
              <button className="px-8 py-4 border-2 border-gray-300 rounded-full font-semibold text-gray-700 hover:border-rose-500 hover:text-rose-500 transition-all duration-300">
                View Collections
              </button>
            </div>
          </div>

          {/* Visual Element */}
          <div className="relative">
            <div className="relative mx-auto w-80 h-80 lg:w-96 lg:h-96">
              {/* Glass Card Effect */}
              <div className="absolute inset-0 bg-white/30 backdrop-blur-sm rounded-3xl shadow-2xl border border-white/50 transform rotate-6 hover:rotate-3 transition-transform duration-500"></div>
              <div className="absolute inset-0 bg-gradient-to-br from-rose-400/20 to-purple-600/20 backdrop-blur-sm rounded-3xl shadow-2xl border border-white/50 transform -rotate-6 hover:-rotate-3 transition-transform duration-500"></div>
              
              {/* Center Content */}
              <div className="relative z-10 flex items-center justify-center h-full">
                <div className="text-center p-8">
                  <div className="text-6xl mb-4">👗</div>
                  <h3 className="text-2xl font-bold text-gray-800 mb-2">Premium Fashion</h3>
                  <p className="text-gray-600">Curated with Love</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;