import React from 'react';
import { Star, Quote } from 'lucide-react';

const Testimonials = () => {
  const testimonials = [
    {
      name: "Jessica Martinez",
      role: "Fashion Blogger",
      avatar: "👩‍💻",
      rating: 5,
      text: "Style has completely transformed my wardrobe! The quality is exceptional and the customer service is unmatched. I get compliments every time I wear their pieces.",
      location: "New York, NY"
    },
    {
      name: "Robert Kim",
      role: "Business Executive", 
      avatar: "👨‍💼",
      rating: 5,
      text: "As someone who values both style and comfort, Style delivers perfectly. Their men's collection is sophisticated yet practical for my busy lifestyle.",
      location: "San Francisco, CA"
    },
    {
      name: "Amanda Foster",
      role: "Working Mom",
      avatar: "👩‍👧",
      rating: 5,
      text: "Finding stylish clothes for both me and my daughter used to be a challenge. Style makes it easy with their amazing collections for the whole family!",
      location: "Austin, TX"
    },
    {
      name: "Carlos Rodriguez",
      role: "Creative Director",
      avatar: "👨‍🎨",
      rating: 5,
      text: "The attention to detail in every piece is remarkable. Style doesn't just sell clothes, they curate experiences. Absolutely love their aesthetic!",
      location: "Miami, FL"
    },
    {
      name: "Sophie Chen",
      role: "Marketing Manager",
      avatar: "👩‍💼",
      rating: 5,
      text: "I've been a loyal customer for over 2 years. The consistency in quality and the fresh designs keep me coming back. Highly recommend!",
      location: "Seattle, WA"
    },
    {
      name: "Daniel Thompson",
      role: "Photographer",
      avatar: "👨‍📷",
      rating: 5,
      text: "As someone who appreciates good design, Style's pieces are not only beautiful but incredibly well-made. They photograph beautifully too!",
      location: "Los Angeles, CA"
    }
  ];

  return (
    <section id="testimonials" className="py-20 bg-gradient-to-b from-purple-50 to-rose-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            What Our <span className="bg-gradient-to-r from-rose-500 to-purple-600 bg-clip-text text-transparent">Customers</span> Say
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Don't just take our word for it. Here's what our amazing customers have to say about their Style experience.
          </p>
        </div>

        {/* Testimonials Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {testimonials.map((testimonial, index) => (
            <div key={index} className="group relative bg-white/70 backdrop-blur-sm rounded-3xl p-8 border border-white/50 shadow-lg hover:shadow-2xl transition-all duration-500 hover:-translate-y-2">
              {/* Quote Icon */}
              <div className="absolute top-6 right-6">
                <Quote className="w-8 h-8 text-rose-200 group-hover:text-rose-300 transition-colors" />
              </div>

              {/* Customer Info */}
              <div className="flex items-center mb-6">
                <div className="w-16 h-16 bg-gradient-to-br from-rose-400 to-purple-500 rounded-full flex items-center justify-center text-2xl mr-4">
                  {testimonial.avatar}
                </div>
                <div>
                  <h4 className="font-bold text-gray-900">{testimonial.name}</h4>
                  <p className="text-sm text-gray-600">{testimonial.role}</p>
                  <p className="text-xs text-gray-500">{testimonial.location}</p>
                </div>
              </div>

              {/* Rating */}
              <div className="flex items-center space-x-1 mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                ))}
              </div>

              {/* Testimonial Text */}
              <p className="text-gray-700 leading-relaxed italic">
                "{testimonial.text}"
              </p>
            </div>
          ))}
        </div>

        {/* Customer Stats */}
        <div className="grid md:grid-cols-4 gap-8 text-center">
          <div className="p-6 bg-white/50 backdrop-blur-sm rounded-2xl border border-white/50">
            <div className="text-3xl font-bold text-rose-500 mb-2">50K+</div>
            <div className="text-gray-600">Happy Customers</div>
          </div>
          <div className="p-6 bg-white/50 backdrop-blur-sm rounded-2xl border border-white/50">
            <div className="text-3xl font-bold text-purple-500 mb-2">4.9</div>
            <div className="text-gray-600">Average Rating</div>
          </div>
          <div className="p-6 bg-white/50 backdrop-blur-sm rounded-2xl border border-white/50">
            <div className="text-3xl font-bold text-emerald-500 mb-2">95%</div>
            <div className="text-gray-600">Repeat Customers</div>
          </div>
          <div className="p-6 bg-white/50 backdrop-blur-sm rounded-2xl border border-white/50">
            <div className="text-3xl font-bold text-rose-500 mb-2">24/7</div>
            <div className="text-gray-600">Customer Support</div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;