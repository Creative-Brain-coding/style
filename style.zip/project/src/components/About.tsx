import React from 'react';
import { Heart, Award, Users, Sparkles } from 'lucide-react';

const About = () => {
  const features = [
    {
      icon: Heart,
      title: "Passionate Design",
      description: "Every piece is carefully selected and designed with love and attention to detail."
    },
    {
      icon: Award,
      title: "Premium Quality",
      description: "We source only the finest materials to ensure lasting comfort and style."
    },
    {
      icon: Users,
      title: "For Everyone",
      description: "Inclusive fashion that celebrates every body type, age, and personal style."
    },
    {
      icon: Sparkles,
      title: "Trendsetting",
      description: "Stay ahead of fashion trends with our cutting-edge designs and collections."
    }
  ];

  return (
    <section id="about" className="py-20 bg-gradient-to-b from-white to-rose-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            About <span className="bg-gradient-to-r from-rose-500 to-purple-600 bg-clip-text text-transparent">Style</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            We believe fashion is more than clothing – it's a form of self-expression, confidence, and art. 
            Since our inception, we've been dedicated to bringing you the finest in contemporary fashion.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
          {features.map((feature, index) => (
            <div key={index} className="group text-center p-6 rounded-2xl bg-white/50 backdrop-blur-sm border border-white/50 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-2">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-rose-400 to-purple-500 rounded-2xl mb-4 group-hover:scale-110 transition-transform duration-300">
                <feature.icon className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">{feature.title}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </div>
          ))}
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <h3 className="text-3xl font-bold text-gray-900 mb-6">Our Story</h3>
            <p className="text-gray-600 mb-6 leading-relaxed">
              Founded with a vision to make high-quality fashion accessible to everyone, Style has grown from a small boutique 
              to a beloved brand trusted by thousands. Our journey began with a simple belief: everyone deserves to feel 
              confident and beautiful in what they wear.
            </p>
            <p className="text-gray-600 mb-8 leading-relaxed">
              Today, we continue to push boundaries in fashion, sustainability, and customer experience. Our collections 
              are thoughtfully curated to offer timeless pieces that transcend seasons and trends, ensuring you always 
              look and feel your best.
            </p>
            <div className="flex flex-wrap gap-8">
              <div className="text-center">
                <div className="text-3xl font-bold text-rose-500">50K+</div>
                <div className="text-gray-600">Happy Customers</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-purple-500">1000+</div>
                <div className="text-gray-600">Unique Designs</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-emerald-500">5+</div>
                <div className="text-gray-600">Years of Excellence</div>
              </div>
            </div>
          </div>
          
          <div className="relative">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-4">
                <div className="h-32 bg-gradient-to-br from-rose-200 to-rose-300 rounded-2xl"></div>
                <div className="h-48 bg-gradient-to-br from-purple-200 to-purple-300 rounded-2xl"></div>
              </div>
              <div className="space-y-4 mt-8">
                <div className="h-48 bg-gradient-to-br from-emerald-200 to-emerald-300 rounded-2xl"></div>
                <div className="h-32 bg-gradient-to-br from-rose-300 to-purple-300 rounded-2xl"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;