import React from 'react';
import { ArrowRight, Star } from 'lucide-react';

const Collections = () => {
  const collections = [
    {
      title: "Women's Collection",
      description: "Elegant and sophisticated pieces for the modern woman",
      image: "👩‍💼",
      items: "250+ Items",
      rating: 4.9,
      priceRange: "$29 - $199",
      gradient: "from-rose-400 to-pink-500"
    },
    {
      title: "Men's Collection", 
      description: "Contemporary styles that blend comfort with sophistication",
      image: "👨‍💼",
      items: "180+ Items",
      rating: 4.8,
      priceRange: "$35 - $179",
      gradient: "from-blue-400 to-indigo-500"
    },
    {
      title: "Children's Collection",
      description: "Playful and comfortable clothing for your little ones",
      image: "👶",
      items: "120+ Items", 
      rating: 4.9,
      priceRange: "$19 - $89",
      gradient: "from-emerald-400 to-teal-500"
    }
  ];

  const deals = [
    { label: "Free Shipping", value: "Orders over $50", icon: "🚚" },
    { label: "30-Day Returns", value: "Easy exchanges", icon: "↩️" },
    { label: "Member Discount", value: "15% off first order", icon: "🎁" },
    { label: "Seasonal Sale", value: "Up to 40% off", icon: "🏷️" }
  ];

  return (
    <section id="collections" className="py-20 bg-gradient-to-b from-rose-50 to-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Our <span className="bg-gradient-to-r from-rose-500 to-purple-600 bg-clip-text text-transparent">Collections</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Discover our carefully curated collections designed to elevate your style and express your unique personality.
          </p>
        </div>

        {/* Collections Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {collections.map((collection, index) => (
            <div key={index} className="group relative overflow-hidden rounded-3xl bg-white shadow-lg hover:shadow-2xl transition-all duration-500 hover:-translate-y-2">
              <div className={`absolute inset-0 bg-gradient-to-br ${collection.gradient} opacity-10 group-hover:opacity-20 transition-opacity duration-300`}></div>
              
              <div className="relative p-8">
                {/* Collection Icon */}
                <div className="text-6xl mb-6 text-center">{collection.image}</div>
                
                {/* Rating */}
                <div className="flex items-center justify-center mb-4">
                  <div className="flex items-center space-x-1">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                    ))}
                    <span className="text-sm text-gray-600 ml-2">({collection.rating})</span>
                  </div>
                </div>

                {/* Content */}
                <h3 className="text-2xl font-bold text-gray-900 mb-3 text-center">{collection.title}</h3>
                <p className="text-gray-600 mb-4 text-center leading-relaxed">{collection.description}</p>
                
                {/* Stats */}
                <div className="flex justify-between items-center mb-6 text-sm text-gray-500">
                  <span>{collection.items}</span>
                  <span>{collection.priceRange}</span>
                </div>

                {/* CTA Button */}
                <button className="w-full group bg-gradient-to-r from-gray-800 to-gray-900 text-white py-3 px-6 rounded-full font-semibold hover:from-rose-500 hover:to-purple-600 transition-all duration-300 flex items-center justify-center">
                  Explore Collection
                  <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Deals Section */}
        <div className="bg-white/50 backdrop-blur-sm rounded-3xl p-8 border border-white/50 shadow-lg">
          <h3 className="text-2xl font-bold text-center text-gray-900 mb-8">Special Offers</h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {deals.map((deal, index) => (
              <div key={index} className="text-center p-6 rounded-2xl bg-gradient-to-br from-rose-50 to-purple-50 hover:from-rose-100 hover:to-purple-100 transition-all duration-300">
                <div className="text-3xl mb-3">{deal.icon}</div>
                <h4 className="font-semibold text-gray-900 mb-2">{deal.label}</h4>
                <p className="text-sm text-gray-600">{deal.value}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Collections;